/************************************************************
Nathan Purta
CompE375 Midterm
Red ID 814071486

This code turns on the LEDs on the Cortex M0 Discovery Board
and allows them to blink at different speeds, which are 
determined by the number pressed on the keypad in milliseconds.
The push button on the board changes which LED blinks. The blue
LED is initially set to blink whenever the code is first 
executed.
**************************************************************/

#include <STM32F0xx.h>
#include <math.h>

void delay(uint32_t ms);
uint32_t BTN_Get(void);
void BTN_Init(void);
void LED_Init (void);
void Audio_Init (void);
void Mode_Set (void);
void initTIM1(void);
uint32_t getKey(void);

int noteNumber[17] = {0,60,62,64,65,67,69,71,0,72,74,76,77,79,81,83,84};  	// noteNumber[i] is the MIDI note number for the
													// key with scancode i; noteNumber[0] is not used
													// since there is no key with scancode 0.
													
float frequency[17];     	// frequency[i] is the frequency in Hertz of 
													// noteNumber[i]
													
float period[17];     	// period[i] is the value to load into the ARR
													// register to produce a PWM wave of frequency
													// frequency[i].  This is the number of cycles of
													// the Timer clock in one cycle of the Timer output.

float dutyCH1 = 100;
float dutyCH2 = 50;
int num = 0;
int scancode;
	
volatile uint32_t msTicks;

int main()
{	
	int i, j;
	//uint8_t noteNumber[17] = {0,60,62,64,65,67,69,71,0,72,74,76,77,79,81,83,84};
	
	uint32_t nextTicks; //Variable used to keep track of current time	
		
	for (i = 0; i < 17; i++)
	{
		if (noteNumber[i] != 0)
		{
			frequency[i] = 27.5 * (float)pow(2,(float)(noteNumber[i] - 21)/12);
			period[i] = SystemCoreClock / (frequency[i] * 100);
		}
		
		else
		{
			frequency[i] = 0;
			period[i] = 0;
		}
	}
	
	
	SystemCoreClockUpdate();   									  //Gets core clock frequency
  if (SysTick_Config(SystemCoreClock / 1000)) 	//Creates loop to catch interrupts
    while (1);																	//Captures interrupt imediately
		
	initTIM1();
	Audio_Init();
	BTN_Init();		//Initializes the push button
	LED_Init();		//Initializes the LEDs
	Mode_Set();		//Sets PC<3:0> to output and PC<7:4> to input
	
	
	
	while(1)
	{
		delay(10);
		scancode = getKey();
		while (scancode != 0)
		{
			scancode = getKey();
			if (scancode != 8 && scancode != 0)
			{
				TIM1->ARR = (period[scancode]);
			}

			else if (scancode == 8)
			{
				while ((scancode > 3 || scancode == 0) && scancode != 15)
					scancode = getKey();				
				
				if (scancode == 1)
				{
					while (getKey() != 0);
					
					while (1)
					{
						GPIOC->BSRR |= (1UL << 8 | 1UL << 9);
						
						nextTicks = msTicks + 500;
						while (msTicks < nextTicks)
						{
							delay(5);
							scancode = getKey();
							if (scancode != 0 && scancode != 15)
							{
								if (scancode < 4)
								{
									num = num * 10 + scancode;
									while (getKey() != 0);
								}
								
								else if (scancode > 4 && scancode < 8)
								{
									num = num * 10 + (scancode - 1);
									while (getKey() != 0);
								}
								
								else if (scancode > 8 && scancode < 12)
								{
									num = num * 10 + (scancode - 2);
									while (getKey() != 0);
								}
								
								else if (scancode == 14)
								{
									num = num * 10;
									while (getKey() != 0);
								}
							}
							
							else if (scancode == 15)
							{
								if (num < 11)
								{
									dutyCH1 = dutyCH1 / 2 / 10 * num;
									TIM1->CCR1 = dutyCH1;
									dutyCH1 = 100;
								}
								num = 0;
								
								while (getKey() != 0);
								
								break;
							}
							delay(5);
						}
						
						GPIOC->BSRR |= (1UL << 24 | 1UL << 25);
						
						while (getKey() != 0);
						
						if (scancode == 15)
							break;
						
						nextTicks = msTicks + 500;
						while (msTicks < nextTicks)
						{
							delay(5);
							scancode = getKey();
							if (scancode != 0 && scancode != 15)
							{
								if (scancode < 4)
								{
									num = num * 10 + scancode;
									while (getKey() != 0);
								}
								
								else if (scancode > 4 && scancode < 8)
								{
									num = num * 10 + (scancode - 1);
									while (getKey() != 0);
								}
								
								else if (scancode > 8 && scancode < 12)
								{
									num = num * 10 + (scancode - 2);
									while (getKey() != 0);
								}
								
								else if (scancode == 14)
								{
									num = num * 10;
									while (getKey() != 0);
								}
							}
							
							else if (scancode == 15)
							{
								if (num < 11)
								{
									dutyCH1 = dutyCH1 / 2 / 10 * num;
									TIM1->CCR1 = dutyCH1;
									dutyCH1 = 100;
								}
								num = 0;
								
								while (getKey() != 0);
								
								break;
							}
							delay(5);
						}
						
						if (scancode == 15)
							break;
						
						//while (getKey() != 0);
					}
					
				}
				
				else if (scancode == 2)
				{
					while (getKey() != 0);
					
					while (1)
					{
						GPIOC->BSRR |= (1UL << 8 | 1UL << 9);
						
						nextTicks = msTicks + 500;
						while (msTicks < nextTicks)
						{
							delay(5);
							scancode = getKey();
							if (scancode != 0 && scancode != 15)
							{
								if (scancode < 4)
								{
									num = num * 10 + scancode;
									while (getKey() != 0);
								}
								
								else if (scancode > 4 && scancode < 8)
								{
									num = num * 10 + (scancode - 1);
									while (getKey() != 0);
								}
								
								else if (scancode > 8 && scancode < 12)
								{
									num = num * 10 + (scancode - 2);
									while (getKey() != 0);
								}
								
								else if (scancode == 14)
								{
									num = num * 10;
									while (getKey() != 0);
								}
							}
							
							else if (scancode == 15)
							{
								if (num < 11)
								{
									dutyCH2 = dutyCH2 / 2 / 10 * num;
									TIM1->CCR2 = dutyCH2;
									dutyCH2 = 50;
								}
								num = 0;
								
								while (getKey() != 0);
								
								break;
							}
							delay(5);
						}
						
						GPIOC->BSRR |= (1UL << 24 | 1UL << 25);
						
						while (getKey() != 0);
						
						if (scancode == 15)
							break;
						
						nextTicks = msTicks + 500;
						while (msTicks < nextTicks)
						{
							delay(5);
							scancode = getKey();
							if (scancode != 0 && scancode != 15)
							{
								if (scancode < 4)
								{
									num = num * 10 + scancode;
									while (getKey() != 0);
								}
								
								else if (scancode > 4 && scancode < 8)
								{
									num = num * 10 + (scancode - 1);
									while (getKey() != 0);
								}
								
								else if (scancode > 8 && scancode < 12)
								{
									num = num * 10 + (scancode - 2);
									while (getKey() != 0);
								}
								
								else if (scancode == 14)
								{
									num = num * 10;
									while (getKey() != 0);
								}
							}
							
							else if (scancode == 15)
							{
								if (num < 11)
								{
									dutyCH2 = dutyCH2 / 2 / 10 * num;
									TIM1->CCR2 = dutyCH2;
									dutyCH2 = 50;
								}
								num = 0;
								
								while (getKey() != 0);
								
								break;
							}
							delay(5);
						}
						
						if (scancode == 15)
							break;
						
						//while (getKey() != 0);
					}
				}
				
				else if (scancode == 3)
				{
					while (getKey() != 0);
					
					while (1)
					{
						GPIOC->BSRR |= (1UL << 8 | 1UL << 9);
						
						nextTicks = msTicks + 500;
						while (msTicks < nextTicks)
						{
							delay(5);
							scancode = getKey();
							if (scancode != 0 && scancode != 15)
							{
								if (scancode < 4)
								{
									num = num * 10 + scancode;
									while (getKey() != 0);
								}
								
								else if (scancode > 4 && scancode < 8)
								{
									num = num * 10 + (scancode - 1);
									while (getKey() != 0);
								}
								
								else if (scancode > 8 && scancode < 12)
								{
									num = num * 10 + (scancode - 2);
									while (getKey() != 0);
								}
								
								else if (scancode == 14)
								{
									num = num * 10;
									while (getKey() != 0);
								}
							}
							
							else if (scancode == 15)
							{
								if (num > 20 && num < 101)
								{
									noteNumber[1] = num;
									for (i = 2; i < 17; i++)
									{
										if (i == 9)
											noteNumber[i] = noteNumber[i-2] + 1;
										else if (i == 4 || i == 12 || i == 16)
											noteNumber[i] = noteNumber[i-1] + 1;
										else if (i != 8)
											noteNumber[i] = noteNumber[i-1] + 2;											
									}
									
									for (j = 0; j < 17; j++)
									{
										if (noteNumber[j] != 0)
										{
											frequency[j] = 27.5 * (float)pow(2,(float)(noteNumber[j] - 21)/12);
											period[j] = SystemCoreClock / (frequency[j] * 100);
										}
										
										else
										{
											frequency[j] = 0;
											period[j] = 0;
										}
									}									
									
								}
								num = 0;
								
								while (getKey() != 0);
								
								break;
							}
							delay(5);
						}
						
						GPIOC->BSRR |= (1UL << 24 | 1UL << 25);
						
						while (getKey() != 0);
						
						if (scancode == 15)
							break;
						
						nextTicks = msTicks + 500;
						while (msTicks < nextTicks)
						{
							delay(5);
							scancode = getKey();
							if (scancode != 0 && scancode != 15)
							{
								if (scancode < 4)
								{
									num = num * 10 + scancode;
									while (getKey() != 0);
								}
								
								else if (scancode > 4 && scancode < 8)
								{
									num = num * 10 + (scancode - 1);
									while (getKey() != 0);
								}
								
								else if (scancode > 8 && scancode < 12)
								{
									num = num * 10 + (scancode - 2);
									while (getKey() != 0);
								}
								
								else if (scancode == 14)
								{
									num = num * 10;
									while (getKey() != 0);
								}
							}
							
							else if (scancode == 15)
							{
								if (num > 20 && num < 101)
								{
									noteNumber[1] = num;
									for (i = 2; i < 17; i++)
									{
										if (i == 9)
											noteNumber[i] = noteNumber[i-2] + 1;
										else if (i == 4 || i == 12 || i == 16)
											noteNumber[i] = noteNumber[i-1] + 1;
										else if (i != 8)
											noteNumber[i] = noteNumber[i-1] + 2;											
									}
									
									for (j = 0; j < 17; j++)
									{
										if (noteNumber[j] != 0)
										{
											frequency[j] = 27.5 * (float)pow(2,(float)(noteNumber[j] - 21)/12);
											period[j] = SystemCoreClock / (frequency[j] * 100);
										}
										
										else
										{
											frequency[j] = 0;
											period[j] = 0;
										}
									}									
									
								}
								num = 0;
								
								while (getKey() != 0);
								
								break;
							}
							delay(5);
						}
						
						if (scancode == 15)
							break;
						
						//while (getKey() != 0);
					}
				}			
			}
			scancode = getKey();
		}	
		
		TIM1->ARR = 0;
		delay(10);
	}
}

//Function that sets the TIM1 registers
void initTIM1(void) 
{
	RCC->APB2ENR = (1UL << 11);
	TIM1->CR1 = 0x00000001;
	TIM1->CR2 = 0x00000500;
	//TIM1->ARR = 0x000007D0;
	TIM1->ARR = 0;
	TIM1->SR = 0x0000001F;
	TIM1->CCMR1 = 0x00006060;
	TIM1->CCER = 0x00000077;
	//TIM1->PSC = 0x00000030;
	TIM1->PSC = 100;
	TIM1->CCR1 = dutyCH1 / 2;
	TIM1->CCR2 = dutyCH2 / 2;
	TIM1->BDTR = 0x00008000;
	TIM1->DMAR = 0x00000001;
}

//Interrupt service routine function
void SysTick_Handler(void)
{
	
	msTicks++;	//Increments clock once every millisecond

}

//Function that returns value of pressed keypad button, if any
uint32_t getKey(void)
{
 	int i;
	
	GPIOC->BSRR &= 0xFFFF0000;		//Sets all pins to 0
	GPIOC->BSRR |= (1UL << 16);		//Resets pin 0 to 0
	GPIOC->BSRR |= (1UL << 1);		//Sets pin 1 to 1
	GPIOC->BSRR |= (1UL << 2);		//Sets pin 2 to 1
	GPIOC->BSRR |= (1UL << 3);		//Sets pin 3 to 1
	
	for (i = 4; i < 8; i++)		//Checks each colum in row 1 if there is a 0 bit
	{
		if ( !(GPIOC->IDR & (1UL << i)) )
			return (i - 3);
	}
	
	GPIOC->BSRR &= 0xFFFF0000;
	GPIOC->BSRR |= (1UL << 0);		//Sets pin 0 to 1
	GPIOC->BSRR |= (1UL << 17);		//Resets pin 1 to 0
	GPIOC->BSRR |= (1UL << 2);		//Sets pin 2 to 1
	GPIOC->BSRR |= (1UL << 3);		//Sets pin 3 to 1
	
	for (i = 4; i < 8; i++)		//Checks each colum in row 2 if there is a 0 bit
	{
		if ( !(GPIOC->IDR & (1UL << i)) )
			return (i + 1);
	}
	
	GPIOC->BSRR &= 0xFFFF0000;
	GPIOC->BSRR |= (1UL << 0);		//Sets pin 0 to 1
	GPIOC->BSRR |= (1UL << 1);		//Sets pin 1 to 1
	GPIOC->BSRR |= (1UL << 18);		//Resets pin 2 to 0
	GPIOC->BSRR |= (1UL << 3);		//Sets pin 3 to 1
	
	for (i = 4; i < 8; i++)	//Checks each colum in row 3 if there is a 0 bit
	{
		if ( !(GPIOC->IDR & (1UL << i)) )
			return (i + 5);
	}
	
	GPIOC->BSRR &= 0xFFFF0000;
	GPIOC->BSRR |= (1UL << 0);		//Sets pin 0 to 1
	GPIOC->BSRR |= (1UL << 1);		//Sets pin 1 to 1
	GPIOC->BSRR |= (1UL << 2);		//Sets pin 2 to 1
	GPIOC->BSRR |= (1UL << 19);		//Resets pin 3 to 0
	
	for (i = 4; i < 8; i++)		//Checks each colum in row 4 if there is a 0 bit
	{
		if ( !(GPIOC->IDR & (1UL << i)) )
			return (i + 9);
	}
	return 0;		//If no button is pressed, return 0
}


//Function that delays code processing for entered amount in milliseconds
void delay(uint32_t dlyTicks)
{
	uint32_t curTicks;

	//Delays the board for the amount of ms that you pass
  curTicks = msTicks;
  while ((msTicks - curTicks) < dlyTicks);
}

//Function that allows the push button to be pressed
void BTN_Init(void) 
{
  RCC->AHBENR  |= ((1UL << 17) );       //Enables clock of port A

  GPIOA->MODER    &= ~((3UL << 0)  );   // Sets pin 0 of A to 00 (Input mode)
  GPIOA->OSPEEDR  &= ~((3UL << 0)  );   // Sets speed of pin 0 of A to 00 (Slow speed)
  GPIOA->PUPDR    &= ~((3UL << 0)  );   // Disables pull up and pull down for pin 0 of A
}

//Functions that allows LEDs to light up
void LED_Init (void) 
{
  //Enable clock for GPIOC
  RCC->AHBENR |= (1UL << 19);	//Clock of port C is bit 19 of AHBENR and is enabled
  GPIOC->MODER  |=  ((1UL << 2 * 8) | (1UL << 2 * 9));	//Sets LEDs to 01 (Output mode)
}

//Function that retrieves the numeric representation of state of the push button
uint32_t BTN_Get(void) 
{
	return (GPIOA->IDR & (1UL << 0));	//Returns the integer value of the button pressed
}

//Function that sets input and output pins
void Mode_Set (void)
{
	GPIOC->MODER |= (1UL << 6);	//Sets pin 3 to output mode (01) (Row 3)
	GPIOC->MODER |= (1UL << 4);	//Sets pin 2 to output mode (01) (Row 2)
	GPIOC->MODER |= (1UL << 2);	//Sets pin 1 to output mode (01) (Row 1)
	GPIOC->MODER |= (1UL << 0);	//Sets pin 0 to output mode (01) (Row 0)
	
	GPIOC->MODER &= ~((3UL << 14));	//Sets pin 7 to input mode (00) (Col 3)
	GPIOC->MODER &= ~((3UL << 12));	//Sets pin 6 to input mode (00) (Col 2)
	GPIOC->MODER &= ~((3UL << 10));	//Sets pin 5 to input mode (00) (Col 1)
	GPIOC->MODER &= ~((3UL << 8));	//Sets pin 4 to input mode (00) (Col 0)
		
	GPIOC->PUPDR |= (1UL << 14);	//Sets pin 7 to pull up (01)
	GPIOC->PUPDR |= (1UL << 12);	//Sets pin 6 to pull up (01)
	GPIOC->PUPDR |= (1UL << 10);	//Sets pin 5 to pull up (01)
	GPIOC->PUPDR |= (1UL << 8);		//Sets pin 4 to pull up (01)
	
	//Sets the AFRH
	GPIOA->AFR[1] &= ~((15UL << 0) | (15UL << 4));	//Sets PA8 and PA9 to 0000 
	GPIOA->AFR[1] |= ((2UL << 0) | (2UL << 4));	//Sets PA8 and PA9 to 0010 
}

void Audio_Init (void) 
{
  //Enable clock for GPIOA
  RCC->AHBENR |= (1UL << 17);	//Clock of port A is bit 17 of AHBENR and is enabled
	
  GPIOA->MODER  |=  ((2UL << 2 * 8) | (2UL << 2 * 9));	//Sets audio to 10 (Output mode)
	GPIOA->OTYPER  &=  ~((1UL << 8) | (1UL << 9));
}
