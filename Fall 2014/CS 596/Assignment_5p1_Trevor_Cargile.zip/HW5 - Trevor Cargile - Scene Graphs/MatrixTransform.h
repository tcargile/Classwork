/*	Trevor Cargile
	813542789
	Homework 5 - MatrixTransform.h		*/

#ifndef _MATRIXTRANSFORM_H_
#define _MATRIXTRANSFORM_H_

#include <vector>
#include "Group.h"
#include "Matrix4.h"

class MatrixTransform : public Group{
public:
	MatrixTransform();
	void draw(Matrix4);				//NOT IMPLEMENTED
	void setTransform(Matrix4);

private:
	Matrix4 transform;
};

#endif