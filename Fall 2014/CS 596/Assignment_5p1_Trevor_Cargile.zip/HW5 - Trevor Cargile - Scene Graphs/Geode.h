/*	Trevor Cargile
	813542789
	Homework 5 - Geode.h		*/

#ifndef _GEODE_H_
#define _GEODE_H_

#include <vector>
#include "Matrix4.h"
#include "Node.h"
#include "Square.h"

class Geode : public Node{
public:
	Geode();
	void addObject(Square);
	void removeObject(std::string);
	void draw(Matrix4);				//NOT IMPLEMENTED

protected:
	std::vector<Square> objects;
};

#endif