/*	Trevor Cargile
	813542789
	Geode.cpp		*/

#include "Geode.h"
#include <GL/glut.h>

using namespace std;

/* Default constructor that is empty. */
Geode::Geode(){}

void Geode::addObject(Square sq){
	//Start from the beginning and then go through each vector Square to see if it exists.
	std::vector<Square>::iterator itr = objects.begin();
	while (itr != objects.end()){
		//If so, print error because squares can't be added twice. (disable this to allow double adding).
		if (itr->getName() == sq.getName()){
			cerr << "Error: Square already exists in the list." << endl;
			break;
		}
		itr++;
	}
	objects.push_back(sq);
}

/* Function to remove a child to the list of children if it exists. */
void Geode::removeObject(std::string sq){
	//Start from the beginning and then go through each vector Node to see if it exists.
	std::vector<Square>::iterator itr = objects.begin();
	for (unsigned int i = 0; i < objects.size(); i++){
		//If so, erase it.
		if (itr->getName() == sq){
			objects.erase(objects.begin() + i);
			return;
		}
		itr++;
	}
	//Print error if node doesn't exist.
	cerr << "Error: Square doesn't exist in object list." << endl;
}

/* Function to draw all objects tied to this node. */
void Geode::draw(Matrix4 world){
	glLoadMatrixd(world.getPointer());
	glBegin(GL_QUADS);

	std::vector<Square>::iterator itr = objects.begin();

	for (unsigned int i = 0; i < objects.size(); i++){
		glColor3f(itr->gR(), itr->gG(), itr->gB());
		glNormal3f(0.0, 0.0, 1.0);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);

		glNormal3f(0.0, 0.0, -1.0);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);

		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);

		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);

		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) - itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);

		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) - itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) + itr->getDim(2) / 2);
		glVertex3f(itr->getCenter(0) + itr->getDim(0) / 2, itr->getCenter(1) + itr->getDim(1) / 2, itr->getCenter(2) - itr->getDim(2) / 2);
	}
	glEnd();
}